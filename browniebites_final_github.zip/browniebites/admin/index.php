<?php
// Include config
require_once '../common/config.php'; // path relative to admin/

// --- Admin Authentication Check ---
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Get admin's name
$admin_name = $_SESSION['admin_name'];
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Admin Dashboard - BrownieBites</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">

    <script>
        // Configure Tailwind theme
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        'brown-dark': '#4B2E05',
                        'caramel': '#c68a4e',
                        'gold': '#FFD700',
                    },
                    fontFamily: {
                        'playfair': ['"Playfair Display"', 'serif'],
                        'poppins': ['Poppins', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        body { user-select: none; }
    </style>
</head>
<body class="bg-gray-900 text-white font-poppins flex">

    <!-- Admin Sidebar -->
    <aside class="w-64 min-h-screen bg-gray-800 p-6 flex flex-col">
        <!-- Admin Logo -->
        <a href="index.php" class="flex items-center space-x-2 group mb-8">
            <div class="w-10 h-10 bg-gold rounded-lg flex items-center justify-center">
                <i class="fa-solid fa-shield-halved fa-lg text-brown-dark"></i>
            </div>
            <span class="font-playfair text-xl font-bold text-white">Admin Panel</span>
        </a>

        <!-- Navigation -->
        <nav class="flex-grow space-y-2">
            <a href="index.php" class="flex items-center space-x-3 px-4 py-3 bg-gray-700/50 rounded-lg text-white">
                <i class="fa-solid fa-tachometer-alt w-5 text-center"></i>
                <span>Dashboard</span>
            </a>
            <a href="menu_manage.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-gray-700/50 hover:text-white transition-colors">
                <i class="fa-solid fa-book-open w-5 text-center"></i>
                <span>Menu Mgt.</span>
            </a>
            <a href="orders_manage.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-gray-700/50 hover:text-white transition-colors">
                <i class="fa-solid fa-box-open w-5 text-center"></i>
                <span>Orders</span>
            </a>
            <a href="offers_manage.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-gray-700/50 hover:text-white transition-colors">
                <i class="fa-solid fa-tags w-5 text-center"></i>
                <span>Offers</span>
            </a>
             <a href="rewards_manage.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-gray-700/50 hover:text-white transition-colors">
                <i class="fa-solid fa-trophy w-5 text-center"></i>
                <span>Rewards</span>
            </a>
            <a href="notifications_send.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-300 hover:bg-gray-700/50 hover:text-white transition-colors">
                <i class="fa-solid fa-bell w-5 text-center"></i>
                <span>Notifications</span>
            </a>
        </nav>

        <!-- Logout -->
        <div class="mt-auto">
             <a href="logout.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg text-red-400 hover:bg-red-500/20 hover:text-red-300 transition-colors">
                <i class="fa-solid fa-sign-out-alt w-5 text-center"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-8">
        <h1 class="text-4xl font-playfair text-white mb-6">Admin Dashboard</h1>
        <p class="text-lg text-gray-300">Welcome, <?php echo e($admin_name); ?>!</p>

        <div class="mt-8 p-6 bg-gray-800/50 border border-white/20 rounded-xl">
            <h2 class="text-2xl font-poppins font-semibold text-gold mb-4">At a Glance</h2>
            <p class="text-gray-300">
                This is where your dashboard widgets will go.
                You can add stats for:
            </p>
            <ul class="list-disc list-inside text-gray-300 mt-4 space-y-2">
                <li>New Orders</li>
                <li>Total Sales</li>
                <li>Menu Items</li>
                <li>Active Users</li>
            </ul>
        </div>

    </main>

    <!-- Global JS -->
    <script src="../assets/js/main.js"></script>
</body>
</html>
