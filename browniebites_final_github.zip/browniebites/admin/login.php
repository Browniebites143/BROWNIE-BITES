<?php
// Include the database connection and session start
require_once '../common/config.php'; // Note the path change

$error_message = '';

// Check if admin is already logged in
if (isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

// --- Handle Admin Login Form Submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error_message = "Email and Password are required.";
    } else {
        // Use prepared statements
        $stmt = $conn->prepare("SELECT admin_id, name, password, role FROM admin WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows === 1) {
            $admin = $result->fetch_assoc();

            // Verify the hashed password
            if (password_verify($password, $admin['password'])) {
                // Password is correct!
                // Set session variables
                $_SESSION['admin_id'] = $admin['admin_id'];
                $_SESSION['admin_name'] = $admin['name'];
                $_SESSION['admin_role'] = $admin['role'];

                // Update last_login timestamp
                $update_stmt = $conn->prepare("UPDATE admin SET last_login = NOW() WHERE admin_id = ?");
                $update_stmt->bind_param("i", $admin['admin_id']);
                $update_stmt->execute();
                $update_stmt->close();

                // Redirect to the admin dashboard
                header('Location: index.php');
                exit;
            } else {
                $error_message = "Invalid email or password.";
            }
        } else {
            $error_message = "Invalid email or password.";
        }
        if ($stmt) $stmt->close();
    }
}
if ($conn) $conn->close();
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Admin Login - BrownieBites</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">

    <script>
        // Configure Tailwind theme
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        'brown-dark': '#4B2E05',
                        'caramel': '#c68a4e',
                        'gold': '#FFD700',
                    },
                    fontFamily: {
                        'playfair': ['"Playfair Display"', 'serif'],
                        'poppins': ['Poppins', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        body { user-select: none; }
    </style>
</head>
<body class="bg-gray-900 text-white font-poppins">

    <div class="min-h-screen flex items-center justify-center p-4" style="background-color: #1a1a1a;">

        <!-- Admin Login Card (Darker Theme) -->
        <div class="w-full max-w-md bg-gray-800/50 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-white/20">

            <!-- Logo & Title -->
            <div class="text-center mb-8">
                <i class="fa-solid fa-shield-halved fa-3x text-gold mb-4"></i>
                <h1 class="text-4xl font-playfair text-white">Admin Panel</h1>
                <p class="text-gray-400 font-light mt-2">BrownieBites Management</p>
            </div>

            <!-- Login Form -->
            <form action="login.php" method="POST" class="space-y-6">

                <?php if ($error_message): ?>
                    <div class="bg-red-500/30 border border-red-500 text-red-100 px-4 py-3 rounded-lg text-center">
                        <?php echo e($error_message); ?>
                    </div>
                <?php endif; ?>

                <!-- Email Input -->
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-300 mb-2">Admin Email</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="fa-solid fa-envelope text-gray-400"></i>
                        </span>
                        <input type="email" id="email" name="email" required
                               class="w-full pl-10 pr-4 py-3 bg-gray-700/50 border border-white/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-gold">
                    </div>
                </div>

                <!-- Password Input -->
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-300 mb-2">Password</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="fa-solid fa-lock text-gray-400"></i>
                        </span>
                        <input type="password" id="password" name="password" required
                               class="w-full pl-10 pr-4 py-3 bg-gray-700/50 border border-white/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-gold">
                    </div>
                </div>

                <!-- Login Button -->
                <button type="submit" name="login"
                        class="w-full py-3 px-4 bg-gradient-to-r from-gold to-caramel text-brown-dark font-bold rounded-lg shadow-lg
                               hover:from-caramel hover:to-gold transition-all duration-300 ease-in-out
                               focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gold">
                    Secure Sign In
                </button>
            </form>
        </div>
    </div>

    <!-- Global JS -->
    <script src="../assets/js/main.js"></script>
</body>
</html>
