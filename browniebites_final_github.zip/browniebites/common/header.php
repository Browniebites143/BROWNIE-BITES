<?php
/*
 * BrownieBites - User Header
 * This is included on all logged-in user pages.
 */
?>
<header class="absolute top-0 left-0 right-0 z-50 p-4">
    <nav class="container mx-auto flex justify-between items-center px-4">

        <!-- Animated Logo -->
        <a href="index.php" class="flex items-center space-x-2 group">
            <!-- Brownie Icon (Animated) -->
            <div class="w-10 h-10 bg-brown-dark rounded-lg flex items-center justify-center 
                        transition-all duration-300 group-hover:rotate-[20deg] group-hover:scale-110">
                <i class="fa-solid fa-cookie-bite fa-lg text-white transition-all duration-300 group-hover:text-gold"></i>
            </div>
            <!-- Text (Animated) -->
            <span class="font-playfair text-2xl font-bold text-white transition-all duration-300 group-hover:text-gold">
                BrownieBites
            </span>
        </a>

        <!-- Right Side Icons -->
        <div class="flex items-center space-x-6">
            <a href="cart.php" class="text-white text-xl hover:text-gold transition-colors relative">
                <i class="fa-solid fa-shopping-cart"></i>
                <!-- Cart counter (example) -->
                <span class="absolute -top-2 -right-2 w-5 h-5 bg-red-600 rounded-full flex items-center justify-center text-xs font-bold">3</span>
            </a>
            <a href="profile.php" class="text-white text-xl hover:text-gold transition-colors">
                <i class="fa-solid fa-user-circle"></i>
            </a>
        </div>
    </nav>
</header>
