<?php
/*
 * BrownieBites - Central Configuration
 * This file is included in all other PHP files.
 * It starts the session and connects to the database.
 */

// Start the session for login tracking
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- Database Configuration ---
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', ''); // Generic empty password for GitHub
define('DB_NAME', 'browniebites_db');

// --- Create Connection ---
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// --- Check Connection ---
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Set character set
$conn->set_charset("utf8mb4");

// --- Helper function for sanitizing output ---
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}
?>
