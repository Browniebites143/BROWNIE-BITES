<?php
/*
 * BrownieBites - User Bottom Navigation
 * This is included on all logged-in user pages for mobile-first navigation.
 */
?>
<!-- Bottom Navigation -->
<nav class="fixed bottom-0 left-0 right-0 z-50 bg-gray-900/70 backdrop-blur-md border-t border-white/20 md:hidden">
    <div class="container mx-auto flex justify-around items-center h-16">

        <a href="index.php" class="flex flex-col items-center justify-center text-gray-300 hover:text-gold transition-colors">
            <i class="fa-solid fa-home fa-lg"></i>
            <span class="text-xs mt-1">Home</span>
        </a>

        <a href="menu.php" class="flex flex-col items-center justify-center text-gray-300 hover:text-gold transition-colors">
            <i class="fa-solid fa-book-open fa-lg"></i>
            <span class="text-xs mt-1">Menu</span>
        </a>

        <a href="offers.php" class="flex flex-col items-center justify-center text-gray-300 hover:text-gold transition-colors">
            <i class="fa-solid fa-tags fa-lg"></i>
            <span class="text-xs mt-1">Offers</span>
        </a>

        <a href="tracking.php" class="flex flex-col items-center justify-center text-gray-300 hover:text-gold transition-colors">
            <i class="fa-solid fa-truck-fast fa-lg"></i>
            <span class="text-xs mt-1">Track</span>
        </a>

        <a href="profile.php" class="flex flex-col items-center justify-center text-gray-300 hover:text-gold transition-colors">
            <i class="fa-solid fa-user fa-lg"></i>
            <span class="text-xs mt-1">Profile</span>
        </a>

    </div>
</nav>
