/*
 * BrownieBites - Global JavaScript
 * This file handles the UX restrictions as requested.
 */
document.addEventListener('DOMContentLoaded', function() {

    // 1. Disable Right-Click
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    }, false);

    // 2. Disable Ctrl/Cmd key combinations for zoom and saving
    document.addEventListener('keydown', function(e) {
        // Normalize key (older browsers)
        const key = e.key || e.keyIdentifier || e.code;
        // Disable Ctrl/Cmd + +, -, 0 (zoom)
        if ((e.ctrlKey || e.metaKey) && (key === '+' || key === '-' || key === '=' || key === '0')) {
            e.preventDefault();
        }
        // Disable Ctrl/Cmd + S (save)
        if ((e.ctrlKey || e.metaKey) && (key === 's' || key === 'S')) {
            e.preventDefault();
        }
    }, false);

    // 3. Disable Wheel Zoom (Ctrl + mouse wheel)
    document.addEventListener('wheel', function(e) {
        if (e.ctrlKey) {
            e.preventDefault();
        }
    }, { passive: false });

    // Note: Text selection is disabled via CSS (user-select: none) in the <style> tag.
    // Note: Pinch-to-zoom is disabled via <meta> tag in the header.

});
